import Logo from "./Logo.png";
import Profile from "./profile.png";
import grid1 from "./grid1Image.png";
import grid2 from "./grid2Image.png";
import grid3 from "./grid3Image.png";
import IconDarkLight from "./IconDarkLight.png";
import profileGrid from "./profileGrid.png";
import WhiteLogo from "./white-logo.png";
import WhiteMsg from "./msg-white.svg";
import Star from "./star.svg";
import HamadPhoto from "./hamad.jpeg";
const Images = { Star, WhiteMsg, Logo, Profile, grid1, grid2, grid3, profileGrid, WhiteLogo, IconDarkLight, HamadPhoto };

export default Images;
